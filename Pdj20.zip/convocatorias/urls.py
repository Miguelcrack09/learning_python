from django.urls import path
from . import views

urlpatterns = [
    path("", views.hola, name="Hola"),
    path("saludos/", views.saludo, name="EL_Saludo"),
    path("parametros/", views.para, name = "Los Parametros"),
    path("miHtml/", views.mihtml, name="Mi primer HTML"),
]