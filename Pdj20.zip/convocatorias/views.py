from django.shortcuts import render
from django.http import HttpResponse

def hola(request):
    return HttpResponse("Hola Clase")

def saludo(request):
    laClase = "S20"
    elSaludo = f"Hola Clase {laClase}!"
    return HttpResponse(elSaludo)

def para(request):
    parametros = "request.GET"
    return HttpResponse(parametros)

def mihtml(request):
    num = ""
    for i in range(1,11):
        num += str(i)+", "
    context = {'nombre': 'Jairo', 'rol': "By su Formador de Frustraciones", 'msg': "LARGA VIDA Y PROPERIDAD!", 'numeros': num}
    return render(request, 'saludos.html', context)